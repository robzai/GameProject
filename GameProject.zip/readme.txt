Team Info: Group 33
Members: Shuang(Rebeccca) Fu, Luo(Leo) Hao, Yao Yao, Rina Hong, Sonny Hoang

Project/Game Name: Free Throw

Description: 
Free Throw is a drag and drop based game. The user is given 3 seconds to memorize a limited number
of objects(pictures). Once the timer is up, the objects flip over, so the user then has to drag the 
corresponding objects into
their appropriate garbage or recycling bins.

Code Structure: 
We divided our code neatly into separate folders. One area of the folder contains only 
HTML pages and we
moved the javascript and CSS materials into its own individual folder to make reading/editing code 
easier for developers and markers.


Technologies used: 
Most of our project was based on HTML, CSS, and javascript. We used Mongo 
DB for developing the leaderboard in
the weekly challenge #2.


Issues/problems encountered: 
During our sprint #2, we were unable to complete the tasks of 
developing an alogorithm to randomize and place
the objects on the screen. We were only able to successfully do this for one out of the many objects. 
We will continue to resolve this problem in sprint #3.

"levelpage.html" doesn't work now, so please run "level1.html" directly to test the game.

